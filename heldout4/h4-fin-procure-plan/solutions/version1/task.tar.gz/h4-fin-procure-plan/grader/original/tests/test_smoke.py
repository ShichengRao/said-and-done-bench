from planner import choose

def test_single_order():
    r={'demand':{'bolt':2},'deadline_days':3,'suppliers':{'s':{'approved':True,'shipping_cents':0,'min_units':1,'max_units':8}},'offers':[{'id':'a','supplier':'s','sku':'bolt','stock':3,'unit_cents':20,'lead_days':2}]}
    assert choose(r)=={'cost_cents':40,'allocation':[{'offer_id':'a','units':2}]}
