def choose(request):
    result=[];cost=0
    for sku,n in request['demand'].items():
        candidates=[o for o in request['offers'] if o['sku']==sku and o['stock']>=n]
        if not candidates:return None
        o=min(candidates,key=lambda o:o['unit_cents'])
        result.append({'offer_id':o['id'],'units':n});cost+=n*o['unit_cents']
    return {'cost_cents':cost,'allocation':sorted(result,key=lambda x:x['offer_id'])}
