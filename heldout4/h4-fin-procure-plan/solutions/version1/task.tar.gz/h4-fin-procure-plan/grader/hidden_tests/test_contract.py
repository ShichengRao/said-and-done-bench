from copy import deepcopy
from itertools import product
import random
from planner import choose

def supplier(ship=0,mn=0,mx=12,ok=True):return dict(approved=ok,shipping_cents=ship,min_units=mn,max_units=mx)
def offer(i,s,sku='x',stock=3,cost=10,lead=1):return dict(id=i,supplier=s,sku=sku,stock=stock,unit_cents=cost,lead_days=lead)
def req(offers,suppliers,demand=None):return dict(demand=demand or {'x':4},deadline_days=2,suppliers=suppliers,offers=offers)
def test_split_rescues_apparent_shortage():
    r=req([offer('a','one',stock=2),offer('b','two',stock=2)],{'one':supplier(5),'two':supplier(7)})
    assert choose(r)=={'cost_cents':52,'allocation':[{'offer_id':'a','units':2},{'offer_id':'b','units':2}]}
def test_shipping_once_and_global_choice():
    r=req([offer('a','cheap','x',3,1),offer('b','cheap','y',3,1),offer('c','shared','x',3,6),offer('d','shared','y',3,6)],{'cheap':supplier(100),'shared':supplier(2)}, {'x':2,'y':2})
    assert choose(r)=={'cost_cents':26,'allocation':[{'offer_id':'c','units':2},{'offer_id':'d','units':2}]}
def test_limits_and_ineligibility():
    r=req([offer('a','small',stock=5,cost=1),offer('b','bad',stock=5,cost=0),offer('c','late',stock=5,cost=0,lead=3),offer('d','ok',stock=5,cost=5)],{'small':supplier(mx=2),'bad':supplier(ok=False),'late':supplier(),'ok':supplier(mn=3)})
    assert choose(r)=={'cost_cents':16,'allocation':[{'offer_id':'a','units':1},{'offer_id':'d','units':3}]}
def test_tie_vector_includes_zero():
    r=req([offer('b','s',stock=5),offer('a','s',stock=5)],{'s':supplier()})
    assert choose(r)=={'cost_cents':40,'allocation':[{'offer_id':'b','units':4}]}
def test_infeasible():
    assert choose(req([],{ })) is None
    assert choose(req([offer('a','s',stock=5)],{'s':supplier(mn=5)})) is None

def oracle(r):
    # Independent recursive enumeration tracks demand and supplier usage incrementally.
    offers=sorted(r['offers'],key=lambda x:x['id']);solutions=[]
    def visit(i,remain,used,vector,subtotal):
        if i==len(offers):
            if any(remain.values()):return
            if any(q and (q<r['suppliers'][s]['min_units'] or q>r['suppliers'][s]['max_units']) for s,q in used.items()):return
            cost=subtotal+sum(r['suppliers'][s]['shipping_cents'] for s,q in used.items() if q)
            solutions.append((cost,tuple(vector)));return
        o=offers[i];s=o['supplier'];sup=r['suppliers'][s]
        maxq=min(o['stock'],remain[o['sku']],sup['max_units']-used.get(s,0)) if sup['approved'] and o['lead_days']<=r['deadline_days'] else 0
        for q in range(maxq+1):
            nxt=dict(remain);nxt[o['sku']]-=q
            nxtused=dict(used);nxtused[s]=nxtused.get(s,0)+q
            visit(i+1,nxt,nxtused,vector+[q],subtotal+q*o['unit_cents'])
    visit(0,dict(r['demand']),{},[],0)
    if not solutions:return None
    cost,vec=min(solutions)
    return {'cost_cents':cost,'allocation':[{'offer_id':o['id'],'units':q} for o,q in zip(offers,vec) if q]}
def test_generated_small_exact_problems_and_no_mutation():
    rng=random.Random(11849)
    for _ in range(40):
        ss={s:supplier(rng.randrange(20),rng.randrange(3),rng.randrange(3,8),rng.random()>.15) for s in ('s','t','u')}
        os=[offer(str(i),rng.choice(list(ss)),rng.choice(['x','y']),rng.randrange(4),rng.randrange(12),rng.randrange(1,5)) for i in range(6)]
        r=req(os,ss,{'x':rng.randrange(1,4),'y':rng.randrange(1,4)});before=deepcopy(r)
        assert choose(r)==oracle(r)
        assert r==before
