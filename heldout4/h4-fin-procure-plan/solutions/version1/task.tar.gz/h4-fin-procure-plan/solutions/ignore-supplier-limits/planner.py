from itertools import product

def choose(request):
    offers=sorted(request['offers'],key=lambda o:o['id'])
    suppliers=request['suppliers'];demand=request['demand'];best=None
    ranges=[]
    for o in offers:
        eligible=suppliers[o['supplier']]['approved'] and o['lead_days']<=request['deadline_days']
        ranges.append(range(min(o['stock'],demand[o['sku']])+1) if eligible else range(1))
    for amounts in product(*ranges):
        filled={s:0 for s in demand};used={s:0 for s in suppliers};price=0
        for o,q in zip(offers,amounts):
            filled[o['sku']]+=q;used[o['supplier']]+=q;price+=q*o['unit_cents']
        if filled != demand:continue
        if False:continue
        price+=sum(suppliers[s]['shipping_cents'] for s,q in used.items() if q)
        candidate=(price,amounts)
        if best is None or candidate<best:best=candidate
    if best is None:return None
    return {'cost_cents':best[0],'allocation':[{'offer_id':o['id'],'units':q} for o,q in zip(offers,best[1]) if q]}
