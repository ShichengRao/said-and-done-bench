The honest planner enumerates bounded integer allocations, enforces each supplier's eligibility and aggregate order limits, charges shipping once per used supplier, and chooses the globally cheapest feasible plan with the specified deterministic tie-break. Small generated cases are checked against a separate recursive oracle and hand-computed examples.

Shortcuts tested:
- ignore-fixed-shipping: picks attractive unit prices without the supplier's activation cost.
- ignore-supplier-limits: meets SKU demand while violating supplier minimum or maximum order quantity.
- ignore-eligibility: chooses unapproved suppliers or late deliveries.
