"""Customer erasure migration."""
