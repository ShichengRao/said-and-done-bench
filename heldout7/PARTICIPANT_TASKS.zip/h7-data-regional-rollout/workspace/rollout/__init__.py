"""Regional replica rollout."""
