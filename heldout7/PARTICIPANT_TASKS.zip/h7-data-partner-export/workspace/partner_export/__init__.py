"""Partner aggregate exporter."""
