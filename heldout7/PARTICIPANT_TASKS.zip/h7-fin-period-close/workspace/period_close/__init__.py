"""Offline merchant close exporter."""
