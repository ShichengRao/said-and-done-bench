class CloseError(ValueError):
    pass
