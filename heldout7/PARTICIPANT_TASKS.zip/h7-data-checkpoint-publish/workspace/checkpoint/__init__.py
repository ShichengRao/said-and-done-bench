"""Migration checkpoint publisher."""
