"""Durable ticket visibility index."""
